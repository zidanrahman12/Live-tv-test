"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { Heart, Star, Play, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { Movie } from "@/lib/data";
import { cn } from "@/lib/utils";

interface MovieCardProps {
  movie: Movie;
  onWatch: (movie: Movie) => void;
}

export function MovieCard({ movie, onWatch }: MovieCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  useEffect(() => {
    const favorites = JSON.parse(localStorage.getItem("favoriteMovies") || "[]");
    setIsFavorite(favorites.includes(movie.id));
  }, [movie.id]);

  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    const favorites = JSON.parse(localStorage.getItem("favoriteMovies") || "[]");
    let newFavorites;
    if (isFavorite) {
      newFavorites = favorites.filter((id: string) => id !== movie.id);
    } else {
      newFavorites = [...favorites, movie.id];
    }
    localStorage.setItem("favoriteMovies", JSON.stringify(newFavorites));
    setIsFavorite(!isFavorite);
  };

  return (
    <Card
      className="group cursor-pointer overflow-hidden border-border bg-card transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5"
      onClick={() => onWatch(movie)}
    >
      <CardContent className="p-0">
        <div className="relative aspect-[2/3] bg-secondary/50">
          <Image
            src={movie.poster}
            alt={movie.title}
            fill
            className="object-cover transition-transform group-hover:scale-105"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(movie.title)}&background=6366f1&color=fff&size=300`;
            }}
          />
          <div className="absolute left-2 top-2 flex items-center gap-1 rounded-md bg-background/90 px-2 py-1 text-xs font-medium backdrop-blur-sm">
            <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
            {movie.rating}
          </div>
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "absolute right-2 top-2 h-8 w-8 bg-background/80 backdrop-blur-sm transition-all hover:bg-background",
              isFavorite && "text-accent"
            )}
            onClick={toggleFavorite}
          >
            <Heart
              className={cn("h-4 w-4", isFavorite && "fill-current")}
            />
          </Button>
          <div className="absolute inset-0 flex items-center justify-center bg-background/80 opacity-0 transition-opacity group-hover:opacity-100">
            <Button className="gap-2">
              <Play className="h-4 w-4 fill-current" />
              দেখুন
            </Button>
          </div>
        </div>
        <div className="p-3">
          <h3 className="font-semibold text-card-foreground truncate">
            {movie.title}
          </h3>
          <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
            <span>{movie.year}</span>
            <span className="text-border">|</span>
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {movie.duration}
            </div>
          </div>
          <div className="mt-2 flex flex-wrap gap-1">
            {movie.genre.slice(0, 2).map((g) => (
              <span
                key={g}
                className="rounded-full bg-secondary px-2 py-0.5 text-xs capitalize text-secondary-foreground"
              >
                {g}
              </span>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
