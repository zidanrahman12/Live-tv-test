"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { Heart, Users, Radio } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { Channel } from "@/lib/data";
import { cn } from "@/lib/utils";

interface ChannelCardProps {
  channel: Channel;
  onWatch: (channel: Channel) => void;
}

export function ChannelCard({ channel, onWatch }: ChannelCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  useEffect(() => {
    const favorites = JSON.parse(localStorage.getItem("favoriteChannels") || "[]");
    setIsFavorite(favorites.includes(channel.id));
  }, [channel.id]);

  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    const favorites = JSON.parse(localStorage.getItem("favoriteChannels") || "[]");
    let newFavorites;
    if (isFavorite) {
      newFavorites = favorites.filter((id: string) => id !== channel.id);
    } else {
      newFavorites = [...favorites, channel.id];
    }
    localStorage.setItem("favoriteChannels", JSON.stringify(newFavorites));
    setIsFavorite(!isFavorite);
  };

  return (
    <Card
      className="group cursor-pointer overflow-hidden border-border bg-card transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5"
      onClick={() => onWatch(channel)}
    >
      <CardContent className="p-0">
        <div className="relative aspect-video bg-secondary/50">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative h-16 w-16 overflow-hidden rounded-lg bg-background p-2">
              <Image
                src={channel.logo}
                alt={channel.name}
                fill
                className="object-contain"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(channel.name)}&background=6366f1&color=fff&size=128`;
                }}
              />
            </div>
          </div>
          {channel.isLive && (
            <div className="absolute left-2 top-2 flex items-center gap-1 rounded-md bg-destructive px-2 py-1 text-xs font-medium text-destructive-foreground">
              <Radio className="h-3 w-3 animate-pulse-live" />
              LIVE
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "absolute right-2 top-2 h-8 w-8 bg-background/80 backdrop-blur-sm transition-all hover:bg-background",
              isFavorite && "text-accent"
            )}
            onClick={toggleFavorite}
          >
            <Heart
              className={cn("h-4 w-4", isFavorite && "fill-current")}
            />
          </Button>
          <div className="absolute inset-0 flex items-center justify-center bg-background/80 opacity-0 transition-opacity group-hover:opacity-100">
            <Button className="gap-2">
              <Radio className="h-4 w-4" />
              দেখুন
            </Button>
          </div>
        </div>
        <div className="p-3">
          <h3 className="font-semibold text-card-foreground truncate">
            {channel.name}
          </h3>
          <div className="mt-1 flex items-center justify-between">
            <span className="text-xs capitalize text-muted-foreground">
              {channel.category}
            </span>
            {channel.viewers && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Users className="h-3 w-3" />
                {(channel.viewers / 1000).toFixed(1)}K
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
