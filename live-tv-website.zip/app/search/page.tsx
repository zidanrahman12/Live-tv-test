"use client";

import { useState, useEffect, useMemo } from "react";
import { Search, Tv, Film, X, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ChannelCard } from "@/components/channel-card";
import { MovieCard } from "@/components/movie-card";
import { VideoPlayer } from "@/components/video-player";
import { fetchChannelsClient, type Channel, type Movie } from "@/lib/data";
import { cn } from "@/lib/utils";

type FilterType = "all" | "channels" | "movies";

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FilterType>("all");
  const [channels, setChannels] = useState<Channel[]>([]);
  const [movies, setMovies] = useState<Movie[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [watchingChannel, setWatchingChannel] = useState<Channel | null>(null);
  const [watchingMovie, setWatchingMovie] = useState<Movie | null>(null);

  // Fetch data on mount
  useEffect(() => {
    async function loadData() {
      setIsLoading(true);
      try {
        const data = await fetchChannelsClient();
        setChannels(data.channels);
        setMovies(data.movies);
      } catch (error) {
        console.error("[v0] Error loading data:", error);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  const filteredChannels = useMemo(() => {
    if (!query.trim()) return [];
    return channels.filter(
      (channel) =>
        channel.name.toLowerCase().includes(query.toLowerCase()) ||
        channel.category.toLowerCase().includes(query.toLowerCase())
    );
  }, [query, channels]);

  const filteredMovies = useMemo(() => {
    if (!query.trim()) return [];
    return movies.filter(
      (movie) =>
        movie.title.toLowerCase().includes(query.toLowerCase()) ||
        movie.genre.some((g) =>
          g.toLowerCase().includes(query.toLowerCase())
        ) ||
        movie.year.toString().includes(query)
    );
  }, [query, movies]);

  const showChannels = filter === "all" || filter === "channels";
  const showMovies = filter === "all" || filter === "movies";

  const hasResults = filteredChannels.length > 0 || filteredMovies.length > 0;
  const hasSearched = query.trim().length > 0;

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      {/* Search Header */}
      <section className="mb-8">
        <h1 className="mb-4 text-3xl font-bold text-foreground">
          সার্চ
        </h1>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="text"
            placeholder="চ্যানেল, মুভি, জেনার খুঁজুন..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="h-14 pl-12 pr-12 text-lg bg-secondary border-border focus:border-primary"
          />
          {query && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-1/2 -translate-y-1/2"
              onClick={() => setQuery("")}
            >
              <X className="h-5 w-5" />
            </Button>
          )}
        </div>
      </section>

      {/* Loading State */}
      {isLoading && (
        <div className="flex flex-col items-center justify-center py-20">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="mt-4 text-muted-foreground">লোড হচ্ছে...</p>
        </div>
      )}

      {!isLoading && (
        <>
          {/* Filter Buttons */}
          {hasSearched && (
            <section className="mb-6">
              <div className="flex gap-2">
                <Button
                  variant={filter === "all" ? "default" : "secondary"}
                  className={cn(
                    filter === "all" && "bg-primary text-primary-foreground"
                  )}
                  onClick={() => setFilter("all")}
                >
                  সব ফলাফল
                </Button>
                <Button
                  variant={filter === "channels" ? "default" : "secondary"}
                  className={cn(
                    "gap-2",
                    filter === "channels" && "bg-primary text-primary-foreground"
                  )}
                  onClick={() => setFilter("channels")}
                >
                  <Tv className="h-4 w-4" />
                  চ্যানেল ({filteredChannels.length})
                </Button>
                <Button
                  variant={filter === "movies" ? "default" : "secondary"}
                  className={cn(
                    "gap-2",
                    filter === "movies" && "bg-primary text-primary-foreground"
                  )}
                  onClick={() => setFilter("movies")}
                >
                  <Film className="h-4 w-4" />
                  মুভি ({filteredMovies.length})
                </Button>
              </div>
            </section>
          )}

          {/* Search Results */}
          {hasSearched ? (
            hasResults ? (
              <div className="space-y-8">
                {/* Channel Results */}
                {showChannels && filteredChannels.length > 0 && (
                  <section>
                    <h2 className="mb-4 flex items-center gap-2 text-xl font-semibold text-foreground">
                      <Tv className="h-5 w-5 text-primary" />
                      চ্যানেল ({filteredChannels.length})
                    </h2>
                    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
                      {filteredChannels.map((channel) => (
                        <ChannelCard
                          key={channel.id}
                          channel={channel}
                          onWatch={setWatchingChannel}
                        />
                      ))}
                    </div>
                  </section>
                )}

                {/* Movie Results */}
                {showMovies && filteredMovies.length > 0 && (
                  <section>
                    <h2 className="mb-4 flex items-center gap-2 text-xl font-semibold text-foreground">
                      <Film className="h-5 w-5 text-accent" />
                      মুভি ({filteredMovies.length})
                    </h2>
                    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                      {filteredMovies.map((movie) => (
                        <MovieCard
                          key={movie.id}
                          movie={movie}
                          onWatch={setWatchingMovie}
                        />
                      ))}
                    </div>
                  </section>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <Search className="h-16 w-16 text-muted-foreground/50" />
                <p className="mt-4 text-lg font-medium text-muted-foreground">
                  &ldquo;{query}&rdquo; এর জন্য কিছু পাওয়া যায়নি
                </p>
                <p className="text-sm text-muted-foreground">
                  অন্য চ্যানেল বা মুভির নাম দিয়ে খুঁজুন
                </p>
              </div>
            )
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Search className="h-16 w-16 text-muted-foreground/50" />
              <p className="mt-4 text-lg font-medium text-muted-foreground">
                খুঁজতে টাইপ করুন
              </p>
              <p className="text-sm text-muted-foreground">
                চ্যানেল, মুভি, জেনার বা বছর দিয়ে খুঁজুন
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-2">
                {["BTV", "NTV", "Bangla", "News", "Sports", "India"].map((term) => (
                  <Button
                    key={term}
                    variant="secondary"
                    size="sm"
                    onClick={() => setQuery(term)}
                  >
                    {term}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* Video Player Modals */}
      {watchingChannel && (
        <VideoPlayer
          title={watchingChannel.name}
          streamUrl={watchingChannel.streamUrl}
          isLive={watchingChannel.isLive}
          onClose={() => setWatchingChannel(null)}
        />
      )}
      {watchingMovie && (
        <VideoPlayer
          title={watchingMovie.title}
          streamUrl={watchingMovie.streamUrl}
          isLive={false}
          onClose={() => setWatchingMovie(null)}
        />
      )}
    </div>
  );
}
