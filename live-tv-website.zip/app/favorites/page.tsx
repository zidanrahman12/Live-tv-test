"use client";

import { useState, useEffect } from "react";
import { Heart, Tv, Film, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ChannelCard } from "@/components/channel-card";
import { MovieCard } from "@/components/movie-card";
import { VideoPlayer } from "@/components/video-player";
import { fetchChannelsClient, type Channel, type Movie } from "@/lib/data";
import { cn } from "@/lib/utils";

type TabType = "channels" | "movies";

export default function FavoritesPage() {
  const [activeTab, setActiveTab] = useState<TabType>("channels");
  const [allChannels, setAllChannels] = useState<Channel[]>([]);
  const [allMovies, setAllMovies] = useState<Movie[]>([]);
  const [favoriteChannels, setFavoriteChannels] = useState<Channel[]>([]);
  const [favoriteMovies, setFavoriteMovies] = useState<Movie[]>([]);
  const [watchingChannel, setWatchingChannel] = useState<Channel | null>(null);
  const [watchingMovie, setWatchingMovie] = useState<Movie | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch all data on mount
  useEffect(() => {
    async function loadData() {
      setIsLoading(true);
      try {
        const data = await fetchChannelsClient();
        setAllChannels(data.channels);
        setAllMovies(data.movies);
      } catch (error) {
        console.error("[v0] Error loading data:", error);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  // Load favorites when data is loaded
  useEffect(() => {
    const loadFavorites = () => {
      const channelIds = JSON.parse(
        localStorage.getItem("favoriteChannels") || "[]"
      );
      const movieIds = JSON.parse(
        localStorage.getItem("favoriteMovies") || "[]"
      );

      setFavoriteChannels(
        allChannels.filter((channel) => channelIds.includes(channel.id))
      );
      setFavoriteMovies(allMovies.filter((movie) => movieIds.includes(movie.id)));
    };

    if (allChannels.length > 0 || allMovies.length > 0) {
      loadFavorites();
    }

    // Listen for storage changes
    const handleStorageChange = () => loadFavorites();
    window.addEventListener("storage", handleStorageChange);

    // Also check periodically for same-tab updates
    const interval = setInterval(loadFavorites, 1000);

    return () => {
      window.removeEventListener("storage", handleStorageChange);
      clearInterval(interval);
    };
  }, [allChannels, allMovies]);

  const totalFavorites = favoriteChannels.length + favoriteMovies.length;

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      {/* Hero Section */}
      <section className="mb-8 overflow-hidden rounded-2xl bg-gradient-to-br from-accent/30 via-secondary to-primary/20 p-6 md:p-10">
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground md:text-4xl">
              আপনার <span className="text-accent">ফেভারিট</span>
            </h1>
            <p className="mt-2 max-w-xl text-muted-foreground">
              আপনার পছন্দের চ্যানেল এবং মুভি এক জায়গায়। যা দেখতে ভালোবাসেন তা দ্রুত অ্যাক্সেস করুন।
            </p>
          </div>
          <div className="flex items-center gap-4 rounded-xl bg-background/60 p-4 backdrop-blur-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent">
              <Heart className="h-6 w-6 fill-accent-foreground text-accent-foreground" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {totalFavorites}
              </p>
              <p className="text-sm text-muted-foreground">মোট ফেভারিট</p>
            </div>
          </div>
        </div>
      </section>

      {/* Loading State */}
      {isLoading && (
        <div className="flex flex-col items-center justify-center py-20">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="mt-4 text-muted-foreground">লোড হচ্ছে...</p>
        </div>
      )}

      {!isLoading && (
        <>
          {/* Tab Buttons */}
          <section className="mb-6">
            <div className="flex gap-2">
              <Button
                variant={activeTab === "channels" ? "default" : "secondary"}
                className={cn(
                  "gap-2",
                  activeTab === "channels" && "bg-primary text-primary-foreground"
                )}
                onClick={() => setActiveTab("channels")}
              >
                <Tv className="h-4 w-4" />
                চ্যানেল ({favoriteChannels.length})
              </Button>
              <Button
                variant={activeTab === "movies" ? "default" : "secondary"}
                className={cn(
                  "gap-2",
                  activeTab === "movies" && "bg-primary text-primary-foreground"
                )}
                onClick={() => setActiveTab("movies")}
              >
                <Film className="h-4 w-4" />
                মুভি ({favoriteMovies.length})
              </Button>
            </div>
          </section>

          {/* Favorite Channels */}
          {activeTab === "channels" && (
            <section>
              {favoriteChannels.length > 0 ? (
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
                  {favoriteChannels.map((channel) => (
                    <ChannelCard
                      key={channel.id}
                      channel={channel}
                      onWatch={setWatchingChannel}
                    />
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <Tv className="h-16 w-16 text-muted-foreground/50" />
                  <p className="mt-4 text-lg font-medium text-muted-foreground">
                    এখনো কোন ফেভারিট চ্যানেল নেই
                  </p>
                  <p className="text-sm text-muted-foreground">
                    যেকোনো চ্যানেলে হার্ট আইকনে ক্লিক করে ফেভারিটে যোগ করুন
                  </p>
                </div>
              )}
            </section>
          )}

          {/* Favorite Movies */}
          {activeTab === "movies" && (
            <section>
              {favoriteMovies.length > 0 ? (
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                  {favoriteMovies.map((movie) => (
                    <MovieCard
                      key={movie.id}
                      movie={movie}
                      onWatch={setWatchingMovie}
                    />
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <Film className="h-16 w-16 text-muted-foreground/50" />
                  <p className="mt-4 text-lg font-medium text-muted-foreground">
                    এখনো কোন ফেভারিট মুভি নেই
                  </p>
                  <p className="text-sm text-muted-foreground">
                    যেকোনো মুভিতে হার্ট আইকনে ক্লিক করে ফেভারিটে যোগ করুন
                  </p>
                </div>
              )}
            </section>
          )}
        </>
      )}

      {/* Video Player Modals */}
      {watchingChannel && (
        <VideoPlayer
          title={watchingChannel.name}
          streamUrl={watchingChannel.streamUrl}
          isLive={watchingChannel.isLive}
          onClose={() => setWatchingChannel(null)}
        />
      )}
      {watchingMovie && (
        <VideoPlayer
          title={watchingMovie.title}
          streamUrl={watchingMovie.streamUrl}
          isLive={false}
          onClose={() => setWatchingMovie(null)}
        />
      )}
    </div>
  );
}
