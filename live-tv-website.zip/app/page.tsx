"use client";

import { useState, useEffect } from "react";
import {
  Tv,
  Flag,
  Trophy,
  Newspaper,
  Film,
  Globe,
  TrendingUp,
  MapPin,
  Baby,
  GraduationCap,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ChannelCard } from "@/components/channel-card";
import { VideoPlayer } from "@/components/video-player";
import { categories, fetchChannelsClient, type Channel } from "@/lib/data";
import { cn } from "@/lib/utils";

const iconMap: Record<string, React.ElementType> = {
  Tv,
  Flag,
  Trophy,
  Newspaper,
  Film,
  Globe,
  MapPin,
  Baby,
  GraduationCap,
};

export default function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [watchingChannel, setWatchingChannel] = useState<Channel | null>(null);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch channels on mount
  useEffect(() => {
    async function loadChannels() {
      setIsLoading(true);
      try {
        const data = await fetchChannelsClient();
        setChannels(data.channels);
      } catch (error) {
        console.error("[v0] Error loading channels:", error);
      } finally {
        setIsLoading(false);
      }
    }
    loadChannels();
  }, []);

  const filteredChannels =
    selectedCategory === "all"
      ? channels
      : channels.filter((channel) => 
          channel.category.toLowerCase().includes(selectedCategory.toLowerCase())
        );

  const featuredChannels = channels
    .filter((c) => c.viewers)
    .sort((a, b) => (b.viewers || 0) - (a.viewers || 0))
    .slice(0, 8);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      {/* Hero Section */}
      <section className="mb-8 overflow-hidden rounded-2xl bg-gradient-to-br from-primary/20 via-secondary to-accent/20 p-6 md:p-10">
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground md:text-4xl">
              লাইভ টিভি দেখুন{" "}
              <span className="text-primary">যেকোনো সময়, যেকোনো জায়গায়</span>
            </h1>
            <p className="mt-2 max-w-xl text-muted-foreground">
              বাংলাদেশী চ্যানেল, স্পোর্টস, নিউজ এবং এন্টারটেইনমেন্ট সরাসরি দেখুন। সব একসাথে।
            </p>
          </div>
          <div className="flex items-center gap-4 rounded-xl bg-background/60 p-4 backdrop-blur-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary">
              <TrendingUp className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {channels.length}+
              </p>
              <p className="text-sm text-muted-foreground">লাইভ চ্যানেল</p>
            </div>
          </div>
        </div>
      </section>

      {/* Loading State */}
      {isLoading && (
        <div className="flex flex-col items-center justify-center py-20">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="mt-4 text-muted-foreground">চ্যানেল লোড হচ্ছে...</p>
        </div>
      )}

      {!isLoading && (
        <>
          {/* Featured Channels */}
          {featuredChannels.length > 0 && (
            <section className="mb-8">
              <h2 className="mb-4 text-xl font-semibold text-foreground">
                ট্রেন্ডিং
              </h2>
              <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                {featuredChannels.slice(0, 4).map((channel) => (
                  <ChannelCard
                    key={channel.id}
                    channel={channel}
                    onWatch={setWatchingChannel}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Category Filter */}
          <section className="mb-6">
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => {
                const Icon = iconMap[category.icon] || Tv;
                const isActive = selectedCategory === category.id;
                return (
                  <Button
                    key={category.id}
                    variant={isActive ? "default" : "secondary"}
                    className={cn(
                      "gap-2",
                      isActive && "bg-primary text-primary-foreground"
                    )}
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <Icon className="h-4 w-4" />
                    {category.name}
                  </Button>
                );
              })}
            </div>
          </section>

          {/* All Channels Grid */}
          <section>
            <h2 className="mb-4 text-xl font-semibold text-foreground">
              {selectedCategory === "all"
                ? "সব চ্যানেল"
                : categories.find((c) => c.id === selectedCategory)?.name}
              {" "}({filteredChannels.length})
            </h2>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
              {filteredChannels.map((channel) => (
                <ChannelCard
                  key={channel.id}
                  channel={channel}
                  onWatch={setWatchingChannel}
                />
              ))}
            </div>

            {filteredChannels.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <Tv className="h-16 w-16 text-muted-foreground/50" />
                <p className="mt-4 text-lg font-medium text-muted-foreground">
                  কোন চ্যানেল পাওয়া যায়নি
                </p>
                <p className="text-sm text-muted-foreground">
                  অন্য ক্যাটেগরি নির্বাচন করুন
                </p>
              </div>
            )}
          </section>
        </>
      )}

      {/* Video Player Modal */}
      {watchingChannel && (
        <VideoPlayer
          title={watchingChannel.name}
          streamUrl={watchingChannel.streamUrl}
          isLive={watchingChannel.isLive}
          onClose={() => setWatchingChannel(null)}
        />
      )}
    </div>
  );
}
