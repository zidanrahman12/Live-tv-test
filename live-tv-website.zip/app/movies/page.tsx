"use client";

import { useState, useEffect } from "react";
import { Film, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MovieCard } from "@/components/movie-card";
import { VideoPlayer } from "@/components/video-player";
import { fetchChannelsClient, movieGenres, type Movie } from "@/lib/data";
import { cn } from "@/lib/utils";

export default function MoviesPage() {
  const [selectedGenre, setSelectedGenre] = useState("all");
  const [watchingMovie, setWatchingMovie] = useState<Movie | null>(null);
  const [movies, setMovies] = useState<Movie[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch movies on mount
  useEffect(() => {
    async function loadMovies() {
      setIsLoading(true);
      try {
        const data = await fetchChannelsClient();
        setMovies(data.movies);
      } catch (error) {
        console.error("[v0] Error loading movies:", error);
      } finally {
        setIsLoading(false);
      }
    }
    loadMovies();
  }, []);

  const filteredMovies =
    selectedGenre === "all"
      ? movies
      : movies.filter((movie) => 
          movie.genre.some(g => g.toLowerCase().includes(selectedGenre.toLowerCase())) ||
          movie.title.toLowerCase().includes(selectedGenre.toLowerCase())
        );

  const featuredMovies = movies.slice(0, 4);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      {/* Hero Section */}
      <section className="mb-8 overflow-hidden rounded-2xl bg-gradient-to-br from-accent/20 via-secondary to-primary/20 p-6 md:p-10">
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground md:text-4xl">
              <span className="text-accent">বাংলা</span> মুভি
            </h1>
            <p className="mt-2 max-w-xl text-muted-foreground">
              বাংলাদেশী সিনেমার সেরা সংগ্রহ। অ্যাকশন থ্রিলার থেকে হৃদয়গ্রাহী ড্রামা, সব আছে এখানে।
            </p>
          </div>
          <div className="flex items-center gap-4 rounded-xl bg-background/60 p-4 backdrop-blur-sm">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent">
              <Film className="h-6 w-6 text-accent-foreground" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {movies.length}+
              </p>
              <p className="text-sm text-muted-foreground">মুভি</p>
            </div>
          </div>
        </div>
      </section>

      {/* Loading State */}
      {isLoading && (
        <div className="flex flex-col items-center justify-center py-20">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="mt-4 text-muted-foreground">মুভি লোড হচ্ছে...</p>
        </div>
      )}

      {!isLoading && (
        <>
          {/* Featured Movies */}
          {featuredMovies.length > 0 && (
            <section className="mb-8">
              <h2 className="mb-4 text-xl font-semibold text-foreground">
                জনপ্রিয় মুভি
              </h2>
              <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
                {featuredMovies.map((movie) => (
                  <MovieCard
                    key={movie.id}
                    movie={movie}
                    onWatch={setWatchingMovie}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Genre Filter */}
          <section className="mb-6">
            <div className="flex flex-wrap gap-2">
              {movieGenres.map((genre) => {
                const isActive = selectedGenre === genre.id;
                return (
                  <Button
                    key={genre.id}
                    variant={isActive ? "default" : "secondary"}
                    className={cn(
                      isActive && "bg-primary text-primary-foreground"
                    )}
                    onClick={() => setSelectedGenre(genre.id)}
                  >
                    {genre.name}
                  </Button>
                );
              })}
            </div>
          </section>

          {/* All Movies Grid */}
          <section>
            <h2 className="mb-4 text-xl font-semibold text-foreground">
              {selectedGenre === "all"
                ? "সব মুভি"
                : movieGenres.find((g) => g.id === selectedGenre)?.name}
              {" "}({filteredMovies.length})
            </h2>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
              {filteredMovies.map((movie) => (
                <MovieCard
                  key={movie.id}
                  movie={movie}
                  onWatch={setWatchingMovie}
                />
              ))}
            </div>

            {filteredMovies.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <Film className="h-16 w-16 text-muted-foreground/50" />
                <p className="mt-4 text-lg font-medium text-muted-foreground">
                  কোন মুভি পাওয়া যায়নি
                </p>
                <p className="text-sm text-muted-foreground">
                  অন্য জেনার নির্বাচন করুন
                </p>
              </div>
            )}
          </section>
        </>
      )}

      {/* Video Player Modal */}
      {watchingMovie && (
        <VideoPlayer
          title={watchingMovie.title}
          streamUrl={watchingMovie.streamUrl}
          isLive={false}
          onClose={() => setWatchingMovie(null)}
        />
      )}
    </div>
  );
}
