export interface Channel {
  id: string;
  name: string;
  logo: string;
  category: string;
  streamUrl: string;
  isLive: boolean;
  viewers?: number;
}

export interface Movie {
  id: string;
  title: string;
  poster: string;
  year: number;
  genre: string[];
  duration: string;
  rating: number;
  description: string;
  streamUrl: string;
}

export const M3U_URL = 'https://raw.githubusercontent.com/time2shine/IPTV/refs/heads/master/combined.m3u';

export const categories = [
  { id: "all", name: "সব চ্যানেল", nameEn: "All Channels", icon: "Tv" },
  { id: "Bangla", name: "বাংলা", nameEn: "Bangla", icon: "Flag" },
  { id: "Bangla News", name: "বাংলা নিউজ", nameEn: "Bangla News", icon: "Newspaper" },
  { id: "International News", name: "আন্তর্জাতিক নিউজ", nameEn: "International News", icon: "Globe" },
  { id: "India", name: "ভারতীয়", nameEn: "Indian", icon: "MapPin" },
  { id: "Pakistan", name: "পাকিস্তান", nameEn: "Pakistan", icon: "MapPin" },
  { id: "Sports", name: "স্পোর্টস", nameEn: "Sports", icon: "Trophy" },
  { id: "Kids", name: "কিডস", nameEn: "Kids", icon: "Baby" },
  { id: "Educational", name: "শিক্ষামূলক", nameEn: "Educational", icon: "GraduationCap" },
  { id: "Movies", name: "মুভি চ্যানেল", nameEn: "Movie Channels", icon: "Film" },
];

export const movieGenres = [
  { id: "all", name: "সব মুভি", nameEn: "All Movies" },
  { id: "Bangla", name: "বাংলা মুভি", nameEn: "Bangla Movies" },
  { id: "Bollywood", name: "বলিউড", nameEn: "Bollywood" },
  { id: "Hollywood", name: "হলিউড", nameEn: "Hollywood" },
  { id: "South", name: "সাউথ", nameEn: "South Indian" },
];

// Parse M3U playlist
export function parseM3U(text: string): { channels: Channel[]; movies: Movie[] } {
  const lines = text.split('\n');
  const channels: Channel[] = [];
  const movies: Movie[] = [];
  let currentItem: {
    name: string;
    group: string;
    logo: string;
    url: string;
  } | null = null;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    if (line.startsWith('#EXTINF:')) {
      const groupMatch = line.match(/group-title="([^"]+)"/);
      const logoMatch = line.match(/tvg-logo="([^"]+)"/);
      const nameMatch = line.match(/,(.+)$/);

      currentItem = {
        name: nameMatch ? nameMatch[1].trim() : 'Unknown',
        group: groupMatch ? groupMatch[1] : 'Other',
        logo: logoMatch ? logoMatch[1] : '',
        url: ''
      };
    } else if (line.startsWith('http') && currentItem) {
      currentItem.url = line;
      
      const group = currentItem.group.toLowerCase();
      const name = currentItem.name.toLowerCase();
      
      // Categorize into channels or movies
      if (group.includes('movie') || name.includes('mov |')) {
        movies.push({
          id: `movie-${movies.length}`,
          title: currentItem.name.replace(/^MOV \| /i, ''),
          poster: currentItem.logo || '',
          year: new Date().getFullYear(),
          genre: [currentItem.group],
          duration: '2h 0m',
          rating: 7.0,
          description: `${currentItem.name} - ${currentItem.group}`,
          streamUrl: currentItem.url,
        });
      } else {
        channels.push({
          id: `channel-${channels.length}`,
          name: currentItem.name,
          logo: currentItem.logo || '',
          category: currentItem.group,
          streamUrl: currentItem.url,
          isLive: true,
          viewers: Math.floor(Math.random() * 50000) + 1000,
        });
      }
      currentItem = null;
    }
  }

  return { channels, movies };
}

// Fetch and parse M3U playlist
export async function fetchChannels(): Promise<{ channels: Channel[]; movies: Movie[] }> {
  try {
    const response = await fetch(M3U_URL, {
      next: { revalidate: 3600 } // Cache for 1 hour
    });
    const text = await response.text();
    return parseM3U(text);
  } catch (error) {
    console.error('Error fetching M3U playlist:', error);
    return { channels: [], movies: [] };
  }
}

// Client-side fetch function
export async function fetchChannelsClient(): Promise<{ channels: Channel[]; movies: Movie[] }> {
  try {
    const response = await fetch(M3U_URL);
    const text = await response.text();
    return parseM3U(text);
  } catch (error) {
    console.error('Error fetching M3U playlist:', error);
    return { channels: [], movies: [] };
  }
}
